package com.lagoinha.connect.model.voluntario;

import com.lagoinha.connect.model.worship.Worship;

public class EscalaIndex {

	String id;
	Worship culto;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Worship getCulto() {
		return culto;
	}
	public void setCulto(Worship culto) {
		this.culto = culto;
	}
	
	
	
}
