package com.lagoinha.connect.model.worship;

public enum Status {
	ABERTO,
	ENCERRADO,
	EXCLUIR
}
