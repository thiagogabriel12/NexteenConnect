package com.lagoinha.connect.model.voluntario;

public class VoluntarioSemCadastro {

	private String nomeVoluntario;
	private String sobrenomeVoluntario;
	private String telefoneVoluntario;
	private String idMinisterio;
	private Boolean checkin;
	private String idEscala;
	public String getNomeVoluntario() {
		return nomeVoluntario;
	}
	public void setNomeVoluntario(String nomeVoluntario) {
		this.nomeVoluntario = nomeVoluntario;
	}
	public String getSobrenomeVoluntario() {
		return sobrenomeVoluntario;
	}
	public void setSobrenomeVoluntario(String sobrenomeVoluntario) {
		this.sobrenomeVoluntario = sobrenomeVoluntario;
	}
	public String getTelefoneVoluntario() {
		return telefoneVoluntario;
	}
	public void setTelefoneVoluntario(String telefoneVoluntario) {
		this.telefoneVoluntario = telefoneVoluntario;
	}
	public String getIdMinisterio() {
		return idMinisterio;
	}
	public void setIdMinisterio(String idMinisterio) {
		this.idMinisterio = idMinisterio;
	}
	public Boolean getCheckin() {
		return checkin;
	}
	public void setCheckin(Boolean checkin) {
		this.checkin = checkin;
	}
	public String getIdEscala() {
		return idEscala;
	}
	public void setIdEscala(String idEscala) {
		this.idEscala = idEscala;
	}
	
	
	
}
