package com.lagoinha.connect.model.worship;

public class WorshipConnect {

	private Integer braceletNumber;
	private String worshipId;
	private String connectId;
	public Integer getBraceletNumber() {
		return braceletNumber;
	}
	public void setBraceletNumber(Integer braceletNumber) {
		this.braceletNumber = braceletNumber;
	}
	public String getWorshipId() {
		return worshipId;
	}
	public void setWorshipId(String worshipId) {
		this.worshipId = worshipId;
	}
	public String getConnectId() {
		return connectId;
	}
	public void setConnectId(String connectId) {
		this.connectId = connectId;
	}
	
	
	
}
