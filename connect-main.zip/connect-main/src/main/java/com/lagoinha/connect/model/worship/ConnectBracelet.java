package com.lagoinha.connect.model.worship;

import com.lagoinha.connect.model.connect.Connect;

public class ConnectBracelet {

	private Connect connect;
	private Integer bracelet;
	public Connect getConnect() {
		return connect;
	}
	public void setConnect(Connect connect) {
		this.connect = connect;
	}
	public Integer getBracelet() {
		return bracelet;
	}
	public void setBracelet(Integer bracelet) {
		this.bracelet = bracelet;
	}
	
	
	
}
