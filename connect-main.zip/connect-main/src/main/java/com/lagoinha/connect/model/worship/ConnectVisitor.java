package com.lagoinha.connect.model.worship;

public class ConnectVisitor {

	private String name;
	private String birthDate;
	private String responsible;
	private String phone;
	private Integer braceletNumber;
	private String idWorship;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBirthDate() {
		return birthDate;
	}
	public void setBirthDate(String birthDate) {
		this.birthDate = birthDate;
	}
	public String getResponsible() {
		return responsible;
	}
	public void setResponsible(String responsible) {
		this.responsible = responsible;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public Integer getBraceletNumber() {
		return braceletNumber;
	}
	public void setBraceletNumber(Integer braceletNumber) {
		this.braceletNumber = braceletNumber;
	}
	public String getIdWorship() {
		return idWorship;
	}
	public void setIdWorship(String idWorship) {
		this.idWorship = idWorship;
	}
	
	
}
